﻿2024-06-02-4

Gulmencoder-vb
Gui for batch files in windows
New version, remade in vb.net, using sharp develop 4
Todo: add apps folder (1gb)

If checking source in sharp develop, build app once (click on green arrow in sharp develop 4), before going to design mode in sharp develop, so it can load gm3vb.panelx from gm3vb.exe

List of reserved words, # followed by four letters:
#rema - remark, ignore line
#sing - add line just once for the first file (example mkdir "myfolder")
#last - add line just once for the last file (example del temp*.*)
#crli - create list of files: file1.txt file2.txt
#path - path to item: for c:\temp\myfile.txt it will be c:\temp\
#ppth - path to gulmencoder.exe: something like c:\apps\gulmencoder\
#item - full path and name: c:\temp\myfile.txt
#inde - for first file in file list: 001, second 002 ...
#name - for c:\temp\myfile.txt it will be myfile
#exte - for c:\temp\myfile.txt it will be .txt
#newl - add newline to bat file


old readme continues below ...
program ver 2023-01-31-1


Utility for making work with command line easier.

Some of the applications:
-convert audio and video files to other formats
-split and merge audio files
-extract audio to mp3, aac, wav
-change divx fourc code
-basic encode dvd
-ocr
-working with pdf files
-working with audio book files, m4b, and mka.
-conditional encoding. check video size, downsize if one dimension too big. Encode audio if not in mp3 format. 
 check "more advanced" presets for examples.
-create movie thumbnails, png and webm animations (best viewed in Opera.). No gif yet.
-renumber files


How to use:
Drag and drop files on program.
Select preset on the right.
Press go.


NOTE: When you start mencoder for the first time, it might take a while to read all the installed fonts.
For example "create divx movie (menc).txt" setting.

Preset files are text files. Content:

<comment> - add comment. everything after this line will be added as a comment.
it will stop when you get to the empty line.



Explanation of commands/keywords:

if you have file named: c:\movies\name of the movie.avi
and you installed program in d:\apps\gulmencoder3\gulmencoder3.exe
you can use the following keywords:

#ppth - program path: "d:\apps\gulmencoder3\" (trailing backslash is included)

#item - the whole item name: "c:\movies\name of the movie.avi"
#path - path to the item: "c:\movies\" (trailing backslash is included)
#name - just the file name item: "name of the movie"
#exte - extension of the item: ".avi"

#newl - newline, add everything, then move to next line. only one per line. Useful if you want to use more than one executable files in program.
	note: #newl has to be at the begining of the line.

#sing - add only once to the batch file. used for example "makedir c:\temp", or "set a=300"
        It will be added only once to the bat file.
	(advanced: The way it is done internal, is, it will be used only with the first item file list)
	note: Only one per script. maybe I'll change this. You can add more bat commands with &. Example: "#sing echo aaa & dir"

#last - executes only if the program is processing the last item in the file list.
	example:
	#newl echo "#item">> d:\list.txt
	#last #newl copy d:\list.txt d:\finally-"#name".txt

	Will copy list to the file containing name of the last item on the list. Not before the last item is done.
	Make sure last action is after the usual processing, not before.

#rema - remark. rest of the line will be ignored. can be written as #remark, too.

#inde = index of a file in a list. Starts from 001.

#crli = create list of files, execute once. Use it when you want to use all the files in the list, such as merging files into one.
see example in D:\apps\gulmencoder3\set\audio\merge audio files (mp3wrap).txt


#.... = this line will not be displayed in gui.



When you write presets, make sure you have one " " at the end. Example: "-vf scale -zoom -xy 512 "
(Unless writing bat files commands, such as "set max=480")

-note:
you can use & to write two commands in a bat file
echo 1
echo 2 
is the same as 
echo 1 & echo 2

&& is conditional, though. http://www.microsoft.com/resources/documentation/windows/xp/all/proddocs/en-us/ntcmds_shelloverview.mspx?mfr=true

-& or && does not work after if. If IF is FALSE, everything after if is discarded, till the end of the line.



Calibre portable and Libre office are not included in the distribution, you have to download them 
yourself and put them in the same dir as Gulmencoder, for example "C:\Program Files"


Updates history:

v 08:10 čet 18.05.2023.
-added convert tex to latex using tinytex(xelatex)
 can also be used for forms (tex to pdf)

changes in 2023-01-31-1
-edited set/movie/download series subtitle from titlovi (python).txt
-edited apps/python - download subtitle/download series subtitle from titlovi.py
-upx updated to 4.02
-ffmpeg updated and compressed using upx


10:14 sri 04.05.2022.
added web screenshot
added yt-dlp
add misterious video link to youtube dl ;)



13:16 cet 07.10.2021.
added option to download subs using titlovi.
browser is used for imdb page screenshot.

updated tesseract-ocr to tesseract v5.0.0-alpha.20210811 64bit.
-oem 0 does not work with new tessdata, but this version is much faster anyway.

15:42 pet 17.09.2021.
added "file operations"\translate, using "python - translate.py" and google translate


++
modificiation of pythod dl movie info, if there is only one file in the zip, it will not append cd1 to its (unzipped) name.
added wkhtmlpdf to the existing wkhtmlimage exe.


-new changes
new apps: coreutils.
13:02 23.12.2015 +ghostxps, convert xps to pdf


new sets: 
 file ops:
  log file size and word count (coreutils)
  split text files in no bigger than 1000k files (coreutils)





Changes in ver 1.2a-beta-2015-11-10
-fixed set for create divx, using rotation


Changes in v1.2a-beta
-various changes.
-updated python - download movies program.
-beta, because I should check and write down added/changed sets/scripts.

Changes in v1.2 1:12 PM 2015-07-22

new command: #last, which executes only if the program is processing the last item in the file list.


in the apps dir, under + are big programs, usually needed for pdf/ocr, that are not needed for regular stuff.

added: 	
merge audio: audio\merge audio files (ffmpeg)
convert to opus: audio\other formats\convert audio to opus (ffmpeg)
extract information from m4b files:
ocr-cuneiform ocr, using command line.
ebook
pdf
audiobooks

Changes in v1.1b
fixed create ebook.txt
added create pdf ebook.

Changes in v1.1a
fixed create ebook.txt
extract pdf, combine pdf added.


Changes in v1.1
-added 
PDF\:
	'convert multipage tiff to pdf', using LibTIFF/Tiff2pdf, A4 page size default.
	'convert PDF to image(s)', using ghostscript, with several image types, & DPI (download from )

OCR: output is now in rtf format.

EBOOKS\:
	convert e-books (callibre portable) to different formats (download from http://calibre-ebook.com/download_portable)
	view e-book (callibre portable view)  (download from http://calibre-ebook.com/download_portable)

movie info download - using 'python - download subtitle.py'. 
Download subtitle, movie page as html, and png.
Python 3.x required, from (download from https://www.python.org/ )
Wkhtmltoimage required for png image saving.   (download from http://wkhtmltopdf.org/)


changes in v1.0g.1
-added file manipulation/append files
-changed internal pdf scaling to from 1200 2400 dpi.
-handbrake cli updated to 0.10

changes in v1.0g

-added "file operations\create file list.txt" setting, for creating list of files, like mp3 playlist
-hanbrake cli settings, for creating mp4 movie files. (handbrake cli file included.)
-webm normal settings
-extract audio with voume increase setting: audio\increase volume settings
-sub2srt rewritten in c++, python version removed
-OCR setting added, you need to install tesseract OCR to use it,
 and ghostscript if you want to use pdf as input.
  (download from https://www.python.org/ and )
 
-portable calibre set added, you need to install calibre to use it
-added upx packer. big exe files are packed with it: ffmpeg, hanbrake, mencoder, mkvtoolnix, mp4box.
 It is in manipulate streams\upx.txt.
 You can decompress files using -d switch.
-mplayer, ffmpeg apps updated. ffplay removed (was not included in the install file.)


changes in v1.0f
added:
-"/audio/remove id tags", using tag from http://synthetic-soul.co.uk/tag/.
-default removal of id tags in "/file operations/split files to audio, (ffmpeg)" script
if you don't want it, delete line: "#newl "#ppthapps\tag\Tag.exe" --remove "
-"/file operations/split files to audio, (ffmpeg)": numbers of files to split audio to: added "30" as option.
-"/manipulate streams/mkv and mp4" scripts

changes in v1.0e

added:
-file operations, "rename - add index to file", preset
-file operations, "extract video part", from the whole video.
-file operations, "split files", split video to more files.
 (select number of files, re-examine flash video files afterwards).
 (ffmpeg: You get out of sync in file 2 if you use "-i, -ss." So default is: "-ss, -i")


-file operations, "split files to audio". (Video/audio-->more audio files). 
 Default setting is "audio codec copy". If your source movie is flash movie, encode audio to mp3,
 unless you want aac audio as output. 
 (-acodec libmp3lame , -ab 128k )

-source can be audio or video file.
 (there is another preset for splitting audio files, set\audio\(mp3split). 
 It can only use audio as input files, and
 you have to rename files later, using file operations\"rename" or "renumber" files)


changes in v1.0d


-added crop options to create divx: menc/ffmpeg

-ofps replaced with -fps
 (explanation:
 -fps <float value>
  Override video framerate. Useful if the original value is wrong or missing.
 -ofps <fps>
  Specify a frames per second (fps) value for the _output_ file, which can be different from that of the source material. Must be set for variable fps (ASF, some MOV) and progressive (30000/1001 fps telecined MPEG) files.)

-added "each frame keyframe.set" preset, to reencode video with each frame as key frame, using ffmpeg.
Using higher quality (big file). Useful for editing file.

(For mencoder it would be:
-ovc lavc -lavcopts vcodec=mpeg4:threads=2:vqscale=1:keyint=1 
or, 
-ovc xvid -xvidencopts threads=2:fixed_quant=1:max_key_interval=1
You change vqscale to 1, to set higher quality, and set keyint to to set each frame as keyframe.
same with xvid codec: fixed_quant=1 for quality, and max_key_interval=1 for keyframe.)




changes in v1.0c
+added log movie encoder to a file
+acodec copy ffmpeg,mencoder mp4 default
+in manipulate streams dir, add mkv scripts. Mkv info, Mkv extracts.


changes in v1.0b
-added preset for moving files in their dir. "c:\file.avi", will be moved to "c:\file\file.avi".
 works on ascii named files only.
-added preset to log all files length in a ... log :). Tab separated values, so you can enter them in Excel/OO Calc.

changes in v1.0a
-fixed calc of video height for ffmpeg. (If result is not even, add 1.)
-#.... command. Do not display in gui.


changes in v1.0
-added #crli command
-added mp3split and mp3wrap
-added simple example for conditional encoding.
-[] and +- for navigating :)
-rename (renumber) files. In "file operations" dir. Useful after split audio files.
-#inde starts from 001, instead of 1

changes in v0.98
-added #rema command.
-fixed bug in more advanced auto detect and resize script.
-added new presets for creating thumbnails, like start encoding from half the length. 
 (if length=12, start from 6secons. usefull for short videos.)
-added #inde = index of a file in a list
-added change fourcc part.
-added in audio section: mobile (wav, 22100, mono, 30s), using -formats (example of using dos variables :) ),
 extract audio using mencoder, so you are not limited to using ffmpeg. ffmpeg cannot extract audio from anything other
 than 2 channel track.
-some other changes



changes in v0.97d
-some changes in more advanced scripts
 added mp2 lavc codec to audio, beware the warnings. It works for me, though. :)
 separated fallback audio setup
-updated apps (mencoder & ffmpeg) versions



changes in v0.97c:

-added goclever fast preset (video: 500kb divx with mencoder, audio: 64kb mono, mp2)
-added preset in "more advanced" dir. It checks width of a video. If it is higher than selected value (say 480), 
 it downsizes video to 480x.
-added preset in "more advanced" dir. It checks if audio codec is mp3. If yes, it does not reencode audio.
 works together with width check.
-added preset in "more advanced" dir. Compare the length of the original video with the encoded one.
 Write values in the log file. Write warning if these two differ.
-program checks for #,!,% in a file name, if found, it asks user to rename video file.
-index.txt - description of each dir content.
-mplayer is now used to get video info, ffprobe info is also displayed.
-new preset with video length check
-added 18 more combo boxes :)
-create divx movie (ffmpeg)(auto calc) preset added. Note: sometimes wmv video info (width & height) is not reported correctly.
-do info: move to the first item on drop list, if no item selected.

changes in v0.96
-renamed to gulmencoder3
-path to mencoder kovensky changed in preset files.
-added short help to status bar.
-added create (single) jpeg thumbnails using ffmpeg and mencoder.
-todo - gif, flash, animated png.



dbojan.github.io