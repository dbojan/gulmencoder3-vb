﻿'
' Created by SharpDevelop.
' User: bojan
' Date: 11/5/2022
' Time: 3:40 PM
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'


Public Class PanelX
	Inherits Panel
	
	Public Sub New()
		Me.AutoScroll = True
	End Sub
	
	Protected Overrides Sub OnMouseEnter(e As System.EventArgs)
		Me.Select()
		MyBase.OnMouseEnter(e)
	End Sub
End Class

Public Partial Class MainForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Dim inMaxComboSize As Integer = 40 '36
	Dim stProgramName As String = "gulmencoder3"
	Dim stFolderSet As String = Application.StartupPath & System.IO.Path.DirectorySeparatorChar & "set"
	Dim stFolderCurrent As String = ""
	
	
	
	Sub MainFormLoad(sender As Object, e As EventArgs)
		
		
		Me.Text = stProgramName
		panel1.AutoScroll = True
		'laStatus.Text = "vb.net edition"
		'laStatus.Text = Application.StartupPath
		
		suComboGen
		'liComboBoxes(0).SelectedIndex = 0
		
		drop.Items.Add("drop")
		drop.Items.Add("files")		
		drop.Items.Add("here")		
		
		
		dropc.Items.Add("DO_CLEAR")	
		dropc.Items.Add("DO_REMOVE")	
		dropc.Items.Add("SET_KEEP")	
		dropc.Items.Add("DO_INFO")	
		dropc.Items.Add("DO_OPEN")	
		
		
		presetc.Items.Add("GO")
		presetc.Items.Add("REFRESH")		
		presetc.Items.Add("EDIT")		
		presetc.Items.Add("EXPLORE")
		presetc.Items.Add("GM")		
		
		If System.IO.Directory.Exists(stFolderSet) Then
			suPopulatePresetList(stFolderSet)
		Else
			laStatus.Text = "No set folder near gm3.exe?"
		End If
		
		
		
	End Sub
	
	
	
	
	
	
	Sub suPopulatePresetList(stDirToDisplay as string)
		preset.Items.Clear
		preset.Items.Add("^^")
		
		For Each folder In System.IO.Directory.GetDirectories(stDirToDisplay)
			preset.Items.Add("+ " & System.IO.Path.GetFileName(folder))
		Next
		
		For Each file In System.IO.Directory.GetFiles(stDirToDisplay)
			
			If System.IO.Path.GetFileName(file) = "index.txt" Then
				Dim lines() As String = IO.File.ReadAllLines(stDirToDisplay & System.IO.Path.DirectorySeparatorChar & "index.txt")
				comment.Items.Clear
				comment.Items.AddRange(lines)
				If comment.Items.Count>0 Then
					comment.SelectedIndex=0
				End If
			Else
				preset.Items.Add("[] " & System.IO.Path.GetFileName(file))
			End If
			
		Next
		
		'top
		stFolderCurrent = stDirToDisplay
		laStatus.Text = "Current dir: " & stFolderCurrent
		
	End Sub
	
	Private liComboBoxes As New List(Of ComboBox)
	
	Sub suComboGen
		
		For i As Integer = 0 To inMaxComboSize -1
			
			Dim newCombo As New ComboBox
			Try ' Start of your Try/Catch block.  		
				With newCombo
					.Name = "ComboBox" & i.ToString
					.Left = 0
					.Top = 30 * i 
					.Width = Me.panel1.Size.Width-20
					.Height = 30
					'.Items.Add("A")
					'.Items.Add("B")
					'.SelectedIndex = 0
					'.Font = New Font("Arial", 10, FontStyle.Regular) '.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Regular)
					.Visible = True
					'.Anchor = AnchorStyles.Left Or AnchorStyles.Right Or AnchorStyles.Top
				End With
				panel1.Controls.Add(newCombo)
				liComboBoxes.Add(newCombo)
				'liComboBoxes(0).Items.Add(1)
			Catch ex As Exception ' Catch your exception.
			End Try ' End the Try/Catch block.
			
		Next i
		
		
	End Sub
	
	
	Sub suComboFill(stFile As String )
		
		
		Dim laDelimiter As String = "|"
		Dim stCounter As Integer = 0
		
		
		Dim lines() As String = IO.File.ReadAllLines(stFile)
		
		
		
		For i = 0 To  inMaxComboSize -1
			liComboBoxes(i).Items.Clear
			liComboBoxes(i).Text="" 'also have to clear currently displayed text, not auto cleared when doing "clear"			
		Next
		
		
		
		Dim streamReader1 As System.IO.StreamReader
		streamReader1 = My.Computer.FileSystem.OpenTextFileReader(stFile)
		Dim stFullLineRead As String
		
		Dim arLine() As String 
		Do
			stFullLineRead = streamReader1.ReadLine()
			
			If stFullLineRead Is Nothing Then 'moving on to comments, if there are any 
				Exit Do
			End If
			
			if stFullLineRead.ToString.Length = 0 Then
				Exit Do
			End If
			
			'more than max liComboBoxes
			If stCounter > inMaxComboSize -1 Then '0-9 = 10
				MessageBox.Show("Number of lines in .set file exceeds number of available combo boxes! " & stCounter+1 & " vs " & inMaxComboSize) 'inmaxcombosize = 10 set before, so no need for -1
				Exit Do
			End If
			
			'stFullLineRead = stFullLineRead.Replace("||","-pipe-temp-holder-") 'so you can use pipe in script
			
			arLine = Split(stFullLineRead, laDelimiter)
			
			
			'If arLine(0).ToString.Length > 0 Then 'first path could be empty, like: |something
			
			For a As Integer = 0 To arLine.Length -1
				'arLine(a) = arLine(a).Replace("-pipe-temp-holder-","|") 'problem if there is a||--something-- already in file .., instead of a| |--something--
				
				liComboBoxes(stCounter).Items.Add(arLine(a))
				liComboBoxes(stCounter).SelectedIndex = 0
				'MessageBox.Show(arLine(a))
			Next
			
			
			
			'Else				
			'	Exit Do
			'End If
			stCounter = stCounter + 1
			
		Loop Until stFullLineRead Is Nothing
		
		'stCounter = 0
		
		
		
		'comment
		comment.Items.Clear
		Do
			
			stFullLineRead = streamReader1.ReadLine()'will skip a line if empty?
			
			If  String.IsNullOrEmpty(stFullLineRead) AndAlso comment.Items.Count>0 Then ' finished adding, empty line will exit
				Exit Do
			End If
			
			
			If Not String.IsNullOrEmpty(stFullLineRead) Andalso stFullLineRead <> "<comment>" Then
				comment.Items.Add(stFullLineRead)
			End If
			
			
			
		Loop Until  stFullLineRead Is Nothing
		
		streamReader1.Close() 
		
		laStatus.Text=preset.Text
	End Sub
	
	
	
	Sub suPresetClickOrKey
		
		If   String.IsNullOrEmpty(preset.Text) Then 'cannot compare if empty
			Exit sub
		End If
		
		Dim stNewItem as String 
		
		If preset.Text.Substring(0,1) = "^" Then 'go up
			
			
			If Not stFolderSet=stFolderCurrent Then 'if not top
				stNewItem = IO.Path.GetDirectoryName(stFolderCurrent)
				
				If System.IO.Directory.Exists(stNewItem)
					suPopulatePresetList(stNewItem)
				End If
			End If
			
			Exit Sub	
		End If
		
		
		
		if  preset.Text.Substring(0,1) = "+" Then 'folder
			stNewItem =  stFolderCurrent & System.IO.Path.DirectorySeparatorChar & preset.Text.Substring(2)
			
			If System.IO.Directory.Exists(stNewItem)
				suPopulatePresetList(stNewItem)
			End If
			
			Exit Sub				
		End If
		
		
		
		if preset.Text.Substring(0,1) = "[" Then 'file
			stNewItem =  stFolderCurrent & System.IO.Path.DirectorySeparatorChar & preset.Text.Substring(3)
			
			If System.IO.file.Exists(stNewItem)
				suComboFill(stNewItem)
			End If
			
			Exit Sub	
		End If
		
	End Sub
	
	
	
	
	
	'##############
	Sub PresetcClick(sender As Object, e As EventArgs)
		Dim stNewItem As String 
		
		If presetc.Text = "EDIT" Then
			
			
			If preset.SelectedIndex >=0 Then 'must select something in preset listbox
				If preset.Text.Substring(0,1) = "[" Then 'file
					stNewItem =  stFolderCurrent & System.IO.Path.DirectorySeparatorChar & preset.Text.Substring(3)
					
					If System.IO.file.Exists(stNewItem)
						System.Diagnostics.Process.Start(stNewItem)
						laStatus.Text=stNewItem
					End If
					
				End If
			End if
			
			Exit Sub	
			
		End If
		
		
		If presetc.Text = "EXPLORE" Then
			
			If System.IO.directory.Exists(stFolderCurrent)
				System.Diagnostics.Process.Start(stFolderCurrent)
			End If
			
			laStatus.Text="EXPLORE"
			Exit Sub	
		End If
		
		
		If presetc.Text = "REFRESH" Then
			
			
			If System.IO.Directory.Exists(stFolderCurrent)
				suPopulatePresetList(stFolderCurrent)
			End If
			
			laStatus.Text="REFRESH"
			Exit Sub	
		End If
		
		If presetc.Text = "GM" Then
			
			If System.IO.directory.Exists(Application.StartupPath)
				System.Diagnostics.Process.Start(Application.StartupPath)
			End If
			
			laStatus.Text="EXPLORE"
			Exit Sub	
		End If
		
		
		
		
		If presetc.Text = "GO" and preset.SelectedIndex >=0 Then 'must select something in preset listbox
			
			
			
			If  drop.Items.Count = 0 Or (drop.Items.Count > 0 AndAlso drop.Items(0).ToString = "drop") Then ' no files; also cannot compare strings if empty listbox ...
				MessageBox.Show("Drop some files first ...")
				Exit Sub
			End If
			
			Dim stComboLine As String
			Dim stWholeLine As String
			Dim stFileLine As String			
			Dim stSaveLocationFile As String = Application.StartupPath & System.IO.Path.DirectorySeparatorChar &  "temp" & System.DateTime.Now.ToString("yyyy-MM-dd-HH_mm_ss") & ".bat"
			
			Dim stListOfFiles As String
			Dim stSearch,stReplace As String
			
			
			'create list of items if needed later
			Dim arDrop(drop.Items.Count - 1) As String 'size as number of items in listbox
			drop.Items.CopyTo(arDrop, 0)'copy files to array
			
			For Each item In arDrop
				stListOfFiles = stListOfFiles & Chr(34) & item & Chr(34) & " "
			Next
			'MessageBox.Show(stListOfFiles)
			
			
			
			
			For indexFile = 0 To arDrop.GetUpperBound(0) 'go over files in drop listbox, GUB same as items.count-1 'prevoius To drop.Items.Count - 1
				stWholeLine = ""
				
				For i As Integer = 0 To inMaxComboSize -1' for 10, 0 to 9, go over liComboBoxes
					
					stComboLine = liComboBoxes(i).Text '(Me.Controls.Find("ComboBox" & i, True) )(0).Text
					
					stSearch = "#rema"
					If stComboLine.ToLower.Contains(stSearch) Then 'skip
						stComboLine = ""
					End If
					
					stSearch = "#sing" ' just once, on the first file
					stReplace = ""
					If stComboLine.Contains(stSearch) Then
						if indexFile = 0 Then
							stComboLine = stComboLine.Replace(stSearch, stReplace)
						Else
							stComboLine = ""
						End If
					End if
					
					stSearch = "#last"
					stReplace = ""
					If stComboLine.Contains(stSearch)  Then
						if indexFile = arDrop.GetUpperBound(0) Then 'last file
							stComboLine = stComboLine.Replace(stSearch, stReplace)
						Else
							stComboLine = ""
						End If
					End If
					
					
					stSearch = "#crli"
					stReplace = stListOfFiles
					If stComboLine.Contains(stSearch) Then
						stComboLine = stComboLine.Replace(stSearch, stReplace)
					End If
					
					stSearch = "#path" ' check if last is not \ ,add \ todo
					stReplace = System.IO.Path.GetDirectoryName(drop.Items(indexFile).ToString) & System.IO.Path.DirectorySeparatorChar
					If stComboLine.Contains(stSearch) Then
						stComboLine = stComboLine.Replace(stSearch, stReplace)
					End If					
					
					stSearch = "#ppth" ' check if last is not \ ,add \ todo
					stReplace = Application.StartupPath & System.IO.Path.DirectorySeparatorChar
					If stComboLine.Contains(stSearch) Then
						stComboLine = stComboLine.Replace(stSearch, stReplace)
					End If		
					
					stSearch = "#item" 
					stReplace = System.IO.Path.GetFullPath(drop.Items(indexFile).ToString)
					If stComboLine.Contains(stSearch) Then
						stComboLine = stComboLine.Replace(stSearch, stReplace)
					End If							
					
					stSearch = "#inde" 
					stReplace = (indexFile + 1).ToString.PadLeft(3,"0")
					If stComboLine.Contains(stSearch) Then
						stComboLine = stComboLine.Replace(stSearch, stReplace)
					End If			
					
					stSearch = "#name" 
					stReplace = System.IO.Path.GetFileNameWithoutExtension(drop.Items(indexFile).ToString)
					If stComboLine.Contains(stSearch) Then
						stComboLine = stComboLine.Replace(stSearch, stReplace)
					End If						
					
					
					stSearch = "#exte" 
					stReplace = System.IO.Path.GetExtension(drop.Items(indexFile).ToString)
					If stComboLine.Contains(stSearch) Then
						stComboLine = stComboLine.Replace(stSearch, stReplace)
					End If	
					
					
					stSearch = "#newl" 
					stReplace = System.Environment.NewLine
					If stComboLine.Contains(stSearch) Then
						stComboLine = stComboLine.Replace(stSearch, stReplace)
					End If	
					
					
					stWholeLine = stWholeLine & stComboLine
					
					'MessageBox.Show(   (Me.Controls.Find("MyComboBox" & i, True) )(0).Text     ) ' returns array, use arr(0) to get first item
					
				Next i
				
				stFileLine = stFileLine & stWholeLine & System.Environment.NewLine 'add newline for each file
				
				'crli
				'MsgBox(drop.Items(indexFile).ToString)
				'MessageBox.Show(stWholeLine)
				
			Next indexFile
			stFileLine = stFileLine & "pause" 'newline before pause already added after fileline
			
			IO.File.WriteAllText(stSaveLocationFile,stFileLine)'IO.File.WriteAllLines(stSaveLocationFile,List2)
			System.Diagnostics.Process.Start(stSaveLocationFile)
			
			Exit Sub	
		End If
		
		
		
		
	End Sub
	
	
	
	
	
	
	
	Sub DropcClick(sender As Object, e As EventArgs)
		laStatus.Text=dropc.Text
		
		If dropc.Text = "DO_CLEAR" Then
			drop.Items.Clear
		End If
		
		If dropc.Text = "DO_REMOVE" Then
			If drop.SelectedIndex >=0 Then
				drop.Items.Remove(drop.SelectedItem)
			Else
				MessageBox.Show("No file selected in file list!")
			End If
		End If
		
		
		If dropc.Text = "DO_OPEN" Then
			If drop.SelectedIndex >=0 Then
				System.Diagnostics.Process.Start(drop.SelectedItem)
			Else
				MessageBox.Show("No file selected in file list!")
			End If
		End If
		
		
		If dropc.Text = "DO_INFO" Then
			If drop.SelectedIndex >=0 Then
				Dim stLine As String
				
				stLine = Chr(34) & Application.StartupPath & System.IO.Path.DirectorySeparatorChar & "apps" & System.IO.Path.DirectorySeparatorChar & "mencoder" & System.IO.Path.DirectorySeparatorChar & "mplayer.exe" &  Chr(34) & " -identify -frames 0 -vo null -ao null " &  Chr(34) & drop.SelectedItem & Chr(34)               
				stLine = stLine & Environment.NewLine & "pause"
				Dim stSaveLocationFile As String
				stSaveLocationFile = Application.StartupPath & System.IO.Path.DirectorySeparatorChar & "temp" & System.DateTime.Now.ToString("yyyy-MM-dd-HH_mm_ss") & ".bat"
				
				IO.File.WriteAllText (stSaveLocationFile,stLine)
				
				System.Diagnostics.Process.Start(stSaveLocationFile)
				
				
			Else
				MessageBox.Show("No file selected in file list!")
			End If
		End If
		
	End Sub
	
	
	
	Sub MainFormResize(sender As Object, e As EventArgs)
		For i As Integer = 0 To inMaxComboSize -1
			liComboBoxes(i).Width = Me.panel1.Size.Width-20
			liComboBoxes(i).SelectionLength = 0
		Next i
	End Sub
	
	
	
	
	Sub MainFormDragDrop(sender As Object, e As DragEventArgs)
		Dim files() As String = e.Data.GetData(DataFormats.FileDrop)
		
		If dropc.Text <> "SET_KEEP" Then
			drop.Items.Clear
		End If
		
		
		' no partial @match function for listbox in .net? :(
		For Each file In files
			drop.Items.Add(file)
			If file.Contains("#") Or file.Contains("!") Or file.Contains("%") Then
				MessageBox.Show("You should probably remove #,!,% from file or folder names.",file)
			End If
		Next
		
		
	End Sub
	
	Sub MainFormDragEnter(sender As Object, e As DragEventArgs)
		e.Effect = DragDropEffects.Copy 
		
	End Sub
	
	
	
	Sub MainFormFormClosed(sender As Object, e As FormClosedEventArgs)
		
		If System.IO.Directory.Exists(Application.StartupPath) Then
			For Each stFile As String In System.IO.Directory.GetFiles(Application.StartupPath, "temp*.bat")
				System.IO.File.Delete(stFile)
			Next
		End If
		
	End Sub
	
	
	
	'#######click
	
	
	Sub PresetSelectedIndexChanged(sender As Object, e As EventArgs)
		suPresetClickOrKey
	End Sub
	

	Sub DropSelectedIndexChanged(sender As Object, e As EventArgs)
		If drop.SelectedIndex > -1 Then
			laStatus.Text = drop.Text
		End If
	End Sub
	

	
	Sub CommentSelectedIndexChanged(sender As Object, e As EventArgs)
		laStatus.Text=comment.Text
	End Sub
	
	
End Class
