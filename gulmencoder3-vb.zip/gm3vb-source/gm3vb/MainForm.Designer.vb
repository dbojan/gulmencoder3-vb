﻿'
' Created by SharpDevelop.
' User: bojan
' Date: 11/5/2022
' Time: 3:40 PM
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'


   
Partial Class MainForm
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.statusStrip1 = New System.Windows.Forms.StatusStrip()
		Me.laStatus = New System.Windows.Forms.ToolStripStatusLabel()
		Me.dropc = New System.Windows.Forms.ListBox()
		Me.presetc = New System.Windows.Forms.ListBox()
		Me.preset = New System.Windows.Forms.ListBox()
		Me.drop = New System.Windows.Forms.ListBox()
		Me.comment = New System.Windows.Forms.ListBox()
		Me.panel1 = New gm3vb.PanelX()
		Me.statusStrip1.SuspendLayout
		Me.SuspendLayout
		'
		'statusStrip1
		'
		Me.statusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.laStatus})
		Me.statusStrip1.Location = New System.Drawing.Point(0, 595)
		Me.statusStrip1.Name = "statusStrip1"
		Me.statusStrip1.Size = New System.Drawing.Size(792, 22)
		Me.statusStrip1.TabIndex = 1
		Me.statusStrip1.Text = "statusStrip1"
		'
		'laStatus
		'
		Me.laStatus.Name = "laStatus"
		Me.laStatus.Size = New System.Drawing.Size(0, 17)
		'
		'dropc
		'
		Me.dropc.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.dropc.FormattingEnabled = true
		Me.dropc.Location = New System.Drawing.Point(689, 220)
		Me.dropc.Name = "dropc"
		Me.dropc.Size = New System.Drawing.Size(91, 82)
		Me.dropc.TabIndex = 3
		AddHandler Me.dropc.Click, AddressOf Me.DropcClick
		'
		'presetc
		'
		Me.presetc.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.presetc.FormattingEnabled = true
		Me.presetc.Location = New System.Drawing.Point(689, 12)
		Me.presetc.Name = "presetc"
		Me.presetc.Size = New System.Drawing.Size(91, 95)
		Me.presetc.TabIndex = 4
		AddHandler Me.presetc.Click, AddressOf Me.PresetcClick
		'
		'preset
		'
		Me.preset.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.preset.FormattingEnabled = true
		Me.preset.Location = New System.Drawing.Point(376, 12)
		Me.preset.Name = "preset"
		Me.preset.Size = New System.Drawing.Size(307, 290)
		Me.preset.TabIndex = 5
		AddHandler Me.preset.Click, AddressOf Me.PresetClick
		AddHandler Me.preset.SelectedIndexChanged, AddressOf Me.PresetSelectedIndexChanged
		'
		'drop
		'
		Me.drop.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.drop.FormattingEnabled = true
		Me.drop.Location = New System.Drawing.Point(689, 113)
		Me.drop.Name = "drop"
		Me.drop.Size = New System.Drawing.Size(91, 95)
		Me.drop.Sorted = true
		Me.drop.TabIndex = 7
		AddHandler Me.drop.Click, AddressOf Me.DropClick
		AddHandler Me.drop.SelectedIndexChanged, AddressOf Me.DropSelectedIndexChanged
		'
		'comment
		'
		Me.comment.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
						Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.comment.FormattingEnabled = true
		Me.comment.HorizontalScrollbar = true
		Me.comment.Location = New System.Drawing.Point(376, 312)
		Me.comment.Name = "comment"
		Me.comment.Size = New System.Drawing.Size(404, 277)
		Me.comment.TabIndex = 8
		AddHandler Me.comment.Click, AddressOf Me.CommentClick
		AddHandler Me.comment.SelectedIndexChanged, AddressOf Me.CommentSelectedIndexChanged
		'
		'panel1
		'
		Me.panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
						Or System.Windows.Forms.AnchorStyles.Left)  _
						Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
		Me.panel1.AutoScroll = true
		Me.panel1.Location = New System.Drawing.Point(12, 12)
		Me.panel1.Name = "panel1"
		Me.panel1.Size = New System.Drawing.Size(358, 577)
		Me.panel1.TabIndex = 0
		'
		'MainForm
		'
		Me.AllowDrop = true
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(792, 617)
		Me.Controls.Add(Me.comment)
		Me.Controls.Add(Me.drop)
		Me.Controls.Add(Me.preset)
		Me.Controls.Add(Me.dropc)
		Me.Controls.Add(Me.presetc)
		Me.Controls.Add(Me.statusStrip1)
		Me.Controls.Add(Me.panel1)
		Me.Name = "MainForm"
		Me.Text = "gm3vb"
		AddHandler FormClosed, AddressOf Me.MainFormFormClosed
		AddHandler Load, AddressOf Me.MainFormLoad
		AddHandler DragDrop, AddressOf Me.MainFormDragDrop
		AddHandler DragEnter, AddressOf Me.MainFormDragEnter
		AddHandler Resize, AddressOf Me.MainFormResize
		Me.statusStrip1.ResumeLayout(false)
		Me.statusStrip1.PerformLayout
		Me.ResumeLayout(false)
		Me.PerformLayout
	End Sub
	Private panel1 As gm3vb.PanelX
	Private laStatus As System.Windows.Forms.ToolStripStatusLabel
	Private comment As System.Windows.Forms.ListBox
	Private preset As System.Windows.Forms.ListBox
	Private presetc As System.Windows.Forms.ListBox
	Private dropc As System.Windows.Forms.ListBox
	Private drop As System.Windows.Forms.ListBox
	Private statusStrip1 As System.Windows.Forms.StatusStrip
	

End Class
